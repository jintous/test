CREATE TABLE IF NOT EXISTS user_text (
    id TEXT PRIMARY KEY,
    text TEXT,
    word_count INT
);
