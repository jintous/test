export interface UserTextMessage {
    userText: string
}